module.exports = {
    'plugins': {
        'autoprefixer': {}
    }
};
